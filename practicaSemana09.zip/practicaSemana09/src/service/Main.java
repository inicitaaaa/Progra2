package service;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import model.Vehiculos;
import model.Productos;


public class Main {

	public static void main(String[] args) {
	
	int tamanioVector;
	int opcion = 0;
	tamanioVector = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la capacidad máxima para agregar vehiculos: " ));
	Vehiculos vehiculoVector[] = new Vehiculos[tamanioVector];
	List<Productos> productos = new ArrayList<>();
	
	
	String menu = "--------------MENU-----------------\n"
				+ "1. Agregar vehículos       \n"
				+ "2. Mostrar vehículos       \n"
				+ "3. Agregar productos       \n"
				+ "4. mostrar productos       \n"
				+ "5. Eliminar productos      \n"
				+ "6. Modificar productos     \n"
				+ "7. Salir                   \n"
				+" ------------------------------------";
	do {
		
		try {
			
			
			opcion = Integer.parseInt(JOptionPane.showInputDialog(null, menu));
			
			switch (opcion) {	//inicio del switch
			case 1: 
				
				 boolean placaRepetida = false;
		         boolean hayEspacioVehiculo = false;

		         for (int i = 0; i < vehiculoVector.length; i++) {
		         if (vehiculoVector[i] == null) {
		        	 hayEspacioVehiculo = true;
		         break;
		    }
		}

		         if (!hayEspacioVehiculo) {
		        	 JOptionPane.showMessageDialog(null, "No hay espacio disponible para añadir un vehiculo.\n"); 
		         break;
		}

		         int numeroPlaca = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la placa del vehiculo: "));

		   
		         for (int i = 0; i < vehiculoVector.length; i++) {
		         if (vehiculoVector[i] != null && vehiculoVector[i].getNumeroPlaca() == numeroPlaca) { 
		        	 placaRepetida = true;
		         break;
		    }
		}

		         if (placaRepetida) {
		        	 JOptionPane.showMessageDialog(null, "Ya existe un vehiculo con dicha placa"); 
			         break;
		    }

		    
		    for (int i = 0; i < vehiculoVector.length; i++) { 
		    if (vehiculoVector[i] == null) {

		        Vehiculos nuevoVehiculo = new Vehiculos();

		        nuevoVehiculo.setCombustible(JOptionPane.showInputDialog("Ingrese el tipo de combustible: "));
		        nuevoVehiculo.setTipoVehiculo(JOptionPane.showInputDialog("Ingrese el tipo de vehiculo: "));
		        nuevoVehiculo.setNumeroPlaca(numeroPlaca);
		        nuevoVehiculo.setEstado(Boolean.parseBoolean(JOptionPane.showInputDialog("Ingrese el estado del vehiculo (false: inactivo, true: activo)")));
		        
		        
		        vehiculoVector[i] = nuevoVehiculo;

		        JOptionPane.showMessageDialog(null, "Vehiculo agregado con exitacion");
		        break;
		    }
		}
				break;
				
			case 2:
				
				int placaBuscar;
				placaBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la placa del vehiculo que desea encontrar: "));
				
				boolean EncontradoV = false;
				
				for (int i = 0; i < vehiculoVector.length; i ++) {
					if (vehiculoVector[i] != null && vehiculoVector[i].getNumeroPlaca() == placaBuscar) {
					JOptionPane.showMessageDialog(null, "Vehiculo encontrado con exito");
					vehiculoVector[i].MostrarInfoVehiculo();
					
					EncontradoV = true;
					}	
				}
				
				if (!EncontradoV) {
					JOptionPane.showMessageDialog(null, "No se ha encontrado vehiculo registrado con esa placa"); 
			         break;
				}
				
				break;
		
			case 3:
				
			Productos producto = new Productos();
			
			producto.setId(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id del producto: ")));
			producto.setNombre(JOptionPane.showInputDialog("Ingrese el nombre del producto: "));
			producto.setEstado(JOptionPane.showInputDialog("Ingrese el estado del producto: "));
			producto.setPrecio(Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del producto: ")));
			
			productos.add(producto);
			
				break;
				
			case 4:
		67676767676767676767676767676776766767676767676767676767667676767676767676767676
				
				
				
				break;
			
			case 5:
				
				break;
				
			case 6:
				
				break;
				
			case 7:
				JOptionPane.showMessageDialog(null, "Gracias por usar!! vuelve pronto caracol");
				break;
				
			default:
				JOptionPane.showMessageDialog(null, "Elige una opción valida", "Error Fatal!!!!!",
						JOptionPane.ERROR_MESSAGE);
				//donde termina el switch
			}
		} catch (NumberFormatException nfe) {
			
			JOptionPane.showMessageDialog(null, "Elige una opción valida", "Error Fatal!!!!!",
					JOptionPane.ERROR_MESSAGE);
		} //donde termina el try
	} while (opcion != 7);
		// donde termina el do 
	}
	
	}
	

