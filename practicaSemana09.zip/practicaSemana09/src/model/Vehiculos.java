package model;

import javax.swing.JOptionPane;

public class Vehiculos {

	private String tipoVehiculo = "";
	private String combustible ="";
	private int numeroPlaca = 0;
	private boolean estado = false;
	
	public Vehiculos() { //el vacio
			
	}
	
	public Vehiculos(String tipoVehiculo, String combustible, int numeroPlaca, boolean estado) { //el lleno
	
		this.tipoVehiculo = tipoVehiculo;
		this.combustible = combustible;
		this.numeroPlaca = numeroPlaca;
		this.estado = estado;
	}

	public String getTipoVehiculo() { //getters y setters 
		return tipoVehiculo;
	}

	public void setTipoVehiculo(String tipoVehiculo) {
		this.tipoVehiculo = tipoVehiculo;
	}

	public String getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}

	public int getNumeroPlaca() {
		return numeroPlaca;
	}

	public void setNumeroPlaca(int numeroPlaca) {
		this.numeroPlaca = numeroPlaca;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	
  }
		
	public void MostrarInfoVehiculo() {
		JOptionPane.showMessageDialog(null, "Tipo: " + tipoVehiculo + "\n" + "combustible: " +  combustible + "\n" + "estado: " + estado);
		
		
	}
}
