package model;

public class Productos {
	
	private int id = 0;
	private double precio = 0.0; 
	private String estado = "";
	private String nombre= "";
	
	public Productos() {

	}

	public Productos(int id, double precio, String estado, String nombre) {
		super();
		this.id = id;
		this.precio = precio;
		this.estado = estado;
		this.nombre = nombre;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}