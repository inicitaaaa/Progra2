package service;

import javax.swing.JOptionPane;

public class adds {
double numero= 0;
	
	do {
	
	Double.parseDouble(JOptionPane.showInputDialog("Digite un numero a divir: "));
		
	} while (numero != 0) { 
		
		if (numero > 0) {
			String resultado = "";
			for (int i = 1; i <numero; i++) {
				resultado = resultado + "\n" + i + "/" + numero + " = " + 
			}
			
		}
		
	}
	 }
}
}
