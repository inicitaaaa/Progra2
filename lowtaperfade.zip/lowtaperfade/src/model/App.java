package model;

import javax.swing.JOptionPane;

public class App {
public static void main(String[] args) throws Exception {
	
	int opcion = Integer.parseInt(JOptionPane.showInputDialog("Digite una opcion: "));
	
	switch(opcion) {
	case 1:
	
	String palabra= "";
		
	while(!palabra.equals("Fin")) {
	palabra = JOptionPane.showInputDialog("Ingrese una palabra(Ingrese Fin para salir): ");	
		
		String deletreado = "";
		for( int i = 0; i < palabra.length(); i++) {
			deletreado = deletreado + " " + palabra.charAt(i);
		
		JOptionPane.showMessageDialog(null, deletreado);
		palabra = JOptionPane.showInputDialog("Ingrese una palabra(Ingrese Fin para salir): ");
	  }
	}
		
		break;
	case 2:
	
		Double numero1;
		Double numero2;
		
		numero1= Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer numero: "));
		numero2= Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
		
		Double resultado1 = numero1 + numero2;
		Double resultado2 = numero1 - numero2;
		Double resultado3 = numero1 / numero2;
		Double resultado4 = numero1 * numero2;
		Double resultado5 = resultado1 + resultado2 + resultado3 + resultado4;
		
		JOptionPane.showMessageDialog(null, numero1 + " + " + numero2 + " = " + resultado1 + "\n" + numero1 + " - " + numero2 + " = " + resultado2 + "\n" + numero1 + " / " + numero2 + " = " + resultado3 + "\n" + numero1 + " x " + numero2 + " = " + resultado4 + "\n" + "suma de todos los resultados: " + resultado5);


		break;
	case 3:
		
		boolean seguir = true;
		
		while(seguir != false) {
		String nombre = JOptionPane.showInputDialog("¿Cual es su nombre?");
		
		JOptionPane.showMessageDialog(null, "Bienvenido/a " + nombre + "un placer conocerle");
		
		Boolean.parseBoolean(JOptionPane.showInputDialog("Desea ingresar otro nombre?"));
		}
		
		
	} 
		
	}
  }

	
	
