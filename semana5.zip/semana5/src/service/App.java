package service;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;

import javax.swing.JOptionPane;

public class App {

	public static void main(String[] args) {
		int opcion = 0;
		 do {
			try {
			
			opcion = Integer.parseInt(JOptionPane.showInputDialog("------------------- MENU ----------------------\n Digite una opción:\n 1. Primer ejercicio \n 2. Segundo ejercicio \n 3. Tercer ejercicio\n 4. Cuarto ejercicio \n 5. Quinto ejercicio \n--------------------------------------------------"));
				
			switch (opcion) 
				{
				case 1: 
					int numero1 = 0;
					int numero2 = 0;
					String numImpar = "";
					
					numero1 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero: "));
					numero2 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
					
					if (numero1 < numero2) {
				
					for (int i = numero1 - 1; i < numero2; i ++) 
						{
					if (i % 2 != 0) {
						numImpar = numImpar + 1 + "";
						JOptionPane.showMessageDialog(null, numImpar);
						}
					}
				}	
				   else {
					JOptionPane.showMessageDialog(null, "El segundo numero debe ser mayor que el primero");
					    
					}
					break;
				case 2:
					
					String nombreInvertido= "";
					String nombre =JOptionPane.showInputDialog("Ingrese su nombre completo: "); ;
					
					for (int i =nombre.length()-1; i>= 0 ; i --) {
						nombreInvertido += nombre.charAt(i) + "";
						if(nombre.charAt(i) == ' ') {
						nombreInvertido = nombreInvertido + "\n";
						}
					}
					JOptionPane.showMessageDialog(null, nombreInvertido);
					
					break;
				case 3:
					
					Double numeroOp = 0.25;
					Double num1 = 0.0;
					Double num2 = 0.0;
					
					num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer numero: "));
					num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
					
					if (num1 < num2) {
						
						while (num1 != num2) {
							num1 = num1 + numeroOp;
							num2 = num2 - numeroOp;
							JOptionPane.showMessageDialog(null, "num1" + num1 + "num2" + num2);
						}
						
					} else {
						while (num1 != num2) {
							num2 = num1 + numeroOp;
							num1 = num2 - numeroOp;
							JOptionPane.showMessageDialog(null, "num1" + num1 + "num2" + num2);					
					  }
					
					}
					break;
				case 4:
					
					LocalDate hoy = LocalDate.now();
					for (int i = 1; i<= 7; i++) {
						JOptionPane.showMessageDialog(null, hoy.plusDays(i));
					}
					break;
				case 5:
					
					
					String nombreC  = "";
					int edad = 0;
			
					nombreC = JOptionPane.showInputDialog("Ingrese su nombre completo: ");
					edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad: "));
					int dia = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dia de su nacimiento: "));
					int mes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el mes de su nacimiento: "));
					int year = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año de su nacimiento: "));
					
					try {
					
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

					String nacimiento = dia + "/" + mes + "/" + year;
					
					Date nacimientoDate = sdf.parse(nacimiento);
					
					JOptionPane.showMessageDialog(null, "su nombre es: " + nombreC + " " + "su edad es: " + edad + " " + "su fecha de nacimiento es: " + nacimiento);
					
					
					}catch(ParseException pe) {
						JOptionPane.showMessageDialog(null, "debe ingresar un valor valido" );
						
					}
					break;
				
				}
			}catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "debe ingresar un valor valido" );}
		} while (opcion != 11);
	}
}
