package model;

import javax.swing.JOptionPane;

public class MembresiaPlatino implements Membresia{

	@Override
	public void obtenerBeneficios() {
		String beneficios= "Descuentos, Regalias, Acceso al lugar";
		JOptionPane.showMessageDialog(null, beneficios);
		
	}

	@Override
	public int obtenerPorcentajeDescuento() {
		return 4;
	}

}
