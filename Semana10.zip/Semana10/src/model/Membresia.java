package model;

public interface Membresia {
	
	public void obtenerBeneficios();

	public int obtenerPorcentajeDescuento();
	
 
	
}
