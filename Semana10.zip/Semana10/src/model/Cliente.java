package model;

public class Cliente {
	
	public String nombre;
	public int cedula;
	public Membresia membresia;
	
	public Cliente (String nombre, int cedula,  Membresia membresia) {
		this.cedula = cedula;
		this.nombre = nombre;
		this.membresia = membresia;
	}
	
	public void obtenerBeneficios() {
		this.membresia.obtenerBeneficios();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCedula() {
		return cedula;
	}

	public void setCedula(int cedula) {
		this.cedula = cedula;
	}

	public Membresia getMembresia() {
		return membresia;
	}

	public void setMembresia(Membresia membresia) {
		this.membresia = membresia;
	}
}
