package model;

public class Servidor {
	
	private static Servidor servidor;
	private static String ip;
	private static String database;
	private static String user;
	private static String pass;
	
	
	private Servidor() {
		super();
	}
	
	public static Servidor getServidor() {
		if (Servidor.servidor == null) {
		servidor = new Servidor();
		ip ="676767";
		database= "123.0.0.1/database";
		user = "vegetta777";
		pass = "1234";
		}
		
	return Servidor.servidor;
	}

	public static String getIp() {
		return ip;
	}

	public static void setIp(String ip) {
		Servidor.ip = ip;
	}

	public static String getDatabase() {
		return database;
	}

	public static void setDatabase(String database) {
		Servidor.database = database;
	}

	public static String getUser() {
		return user;
	}

	public static void setUser(String user) {
		Servidor.user = user;
	}

	public static String getPass() {
		return pass;
	}

	public static void setPass(String pass) {
		Servidor.pass = pass;
	}

	public static void setServidor(Servidor servidor) {
		Servidor.servidor = servidor;
	}
}
