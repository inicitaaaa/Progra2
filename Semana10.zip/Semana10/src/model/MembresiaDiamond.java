package model;

import javax.swing.JOptionPane;

public class MembresiaDiamond implements Membresia{

	@Override
	public void obtenerBeneficios() {

		String beneficios = "super descuentos, acceso al lugar, spam porno";
		JOptionPane.showMessageDialog(null, beneficios);
	}

	@Override
	public int obtenerPorcentajeDescuento() {
		    return 25;
	}
	

}
