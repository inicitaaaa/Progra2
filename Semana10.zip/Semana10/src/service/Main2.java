package service;

import javax.swing.JOptionPane;
import model.MembresiaDiamond;

public class Main2 {

	public static void main(String[] args) {
		
		MembresiaDiamond  diamond = new MembresiaDiamond();
		String nombre = JOptionPane.showInternalInputDialog(null, "Ingrese el nombre: ");
		int cedula= Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cedula"));
		

	}

}
