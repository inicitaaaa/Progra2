package service;

import javax.swing.JOptionPane;
import model.Servidor;

public class Main {
	
	public static void main(String[] args) {
		Servidor serv1 = Servidor.getServidor();
		
		JOptionPane.showInternalMessageDialog(null, serv1.getDatabase() + " - " + serv1.getIp() );
		
		Servidor serv2 = Servidor.getServidor();
		
		JOptionPane.showInternalMessageDialog(null, serv2.getDatabase() + " - " + serv2.getIp() );
		
	
 }
}
