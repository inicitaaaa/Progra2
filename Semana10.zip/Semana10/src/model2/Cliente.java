package model2;

public class Cliente {
	
	public String nombre;
	public int cedula;
	public Descuento descuento;
	
	public Cliente(String nombre, int cedula, Descuento descuento) {
		super();
		this.nombre = nombre;
		this.cedula = cedula;
		this.descuento = descuento;
	}
	
	public void obtenerBeneficios() {
		this.descuento.ObtenerDescuento();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCedula() {
		return cedula;
	}

	public void setCedula(int cedula) {
		this.cedula = cedula;
	}

	public Descuento getDescuento() {
		return descuento;
	}

	public void setDescuento(Descuento descuento) {
		this.descuento = descuento;
	}
	
	
	

}
