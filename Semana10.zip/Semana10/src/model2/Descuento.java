package model2;

public interface Descuento {

	public void ObtenerDescuento();

	
	
	
	
	
}
