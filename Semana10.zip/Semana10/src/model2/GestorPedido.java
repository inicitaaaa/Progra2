package model2;

public class GestorPedido {
	
	private static GestorPedido gestorpedido;
	private static int totalPedidosProcesados = 0;
	private static String estrategiaDescuento = "";
	private static String estadoActual= "";
	
	private GestorPedido() {
		super();
	}
	
	public static GestorPedido getGestorpedido() {
		if (GestorPedido.gestorpedido == null) {
		gestorpedido = new GestorPedido();
		totalPedidosProcesados = 67;
		estrategiaDescuento = "Temporada";
		estadoActual = "pendiente";
		}
	return GestorPedido.gestorpedido;

	}

	public static int getTotalPedidosProcesados() {
		return totalPedidosProcesados;
	}

	public static void setTotalPedidosProcesados(int totalPedidosProcesados) {
		GestorPedido.totalPedidosProcesados = totalPedidosProcesados;
	}

	public static String getEstrategiaDescuento() {
		return estrategiaDescuento;
	}

	public static void setEstrategiaDescuento(String estrategiaDescuento) {
		GestorPedido.estrategiaDescuento = estrategiaDescuento;
	}

	public static String getEstadoActual() {
		return estadoActual;
	}

	public static void setEstadoActual(String estadoActual) {
		GestorPedido.estadoActual = estadoActual;
	}

	public static void setGestorpedido(GestorPedido gestorpedido) {
		GestorPedido.gestorpedido = gestorpedido;
	}
	

    }

