package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Calculadora;

class PruebaMate {
	int num1 = 0;
	int num2 = 0;

	@BeforeAll
	static void BeforeAll() throws Exception{
		JOptionPane.showMessageDialog(null, "Iniciando pruebas de matematica bib bub");	
	}
	
	@BeforeEach
	void metodoBE() throws Exception{

	}
	@Test
	void testSumar() {
		JOptionPane.showMessageDialog(null, "Iniciando test de sumar ");	
		Calculadora calc = new Calculadora();
		int resultado = calc.Sumar(5, 3);
		assertEquals(8, resultado);
	}
	@Test
	void testRestar() {
		JOptionPane.showMessageDialog(null, "Iniciando test de Restar ");	
		Calculadora calc = new Calculadora();
		int resultado = calc.Restar(5, 4);
		assertEquals(1, resultado);
	}
	@Test
	void testMultiplicar() {
		JOptionPane.showMessageDialog(null, "Iniciando test de Multiplicar ");	
		Calculadora calc = new Calculadora();
		int resultado = calc.Multiplicar(2, 5);
		assertEquals(10, resultado);
	}
	@Test
	void testDividir() {
		JOptionPane.showMessageDialog(null, "Iniciando test de Dividir ");	
		Calculadora calc = new Calculadora();
		int resultado = calc.Dividir(10, 5);
		assertEquals(2, resultado);
	}
	@AfterAll
	static void metodoAA() throws Exception {
		JOptionPane.showMessageDialog(null, "Finalizando prueba matematica bip bup"); 
	}	

}
