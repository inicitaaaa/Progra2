package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Funcionario;

class FuncionarioTest {
	static Funcionario funcionario;
	int a;
	int b;
	
	@BeforeAll
	static void inicializador() throws Exception{
		JOptionPane.showMessageDialog(null, "Iniciando variable funcionario ");	
		funcionario = new Funcionario();
	}
	@BeforeEach
	void inicializadorVari() throws Exception{
		a = 0;
		b = 0;
	}
	@Test
	void testMayor() {
		JOptionPane.showMessageDialog(null, "Iniciando test Mayor ");	
		a = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero: "));	
		b = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese otro numero:"));	
		assertTrue(" a no es mayor b ",funcionario.esMayor(a, b));
	}
	@Test
	void testIgual() {
		JOptionPane.showMessageDialog(null, "Iniciando test Igual ");	
		a = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero: "));	
		b = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese otro numero:"));	
		assertTrue(" a no es igual b ",funcionario.esIgual(a, b));
	}
	@Test
	void testMenor() {
		JOptionPane.showMessageDialog(null, "Iniciando test Menor ");	
		a = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero: "));	
		b = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese otro numero:"));	
		assertTrue(" a no es menor b ",funcionario.esMenor(a, b));
	}
	@AfterEach
	void finalizaciondeltest() throws Exception{
		JOptionPane.showMessageDialog(null, "Valor a: " + a + "\nValor b: " + b );	
	}
	@AfterAll
	static void finalizacion()throws Exception {
		JOptionPane.showMessageDialog(null, "Cerrando Sistema");	

	}

}
