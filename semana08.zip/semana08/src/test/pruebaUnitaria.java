package test;

import static org.junit.jupiter.api.Assertions.*;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class pruebaUnitaria {
	static int count= 0;
	
	@BeforeAll
	static void metodoBA() throws Exception {
		JOptionPane.showMessageDialog(null, "Iniciando prueba unitaria bip bup ");	
	}
	@BeforeEach
	void metodoBE() throws Exception{
		count++;
		JOptionPane.showMessageDialog(null, "Iniciando prueba unitaria #" + count);
	}
	@Test
	void test1() {
		JOptionPane.showMessageDialog(null, "Iniciando test 1");	
	}
	@Test
	void test2() {
		JOptionPane.showMessageDialog(null, "Iniciando test 2");	
	}
	@AfterEach
	 void metodoAE() throws Exception{
		JOptionPane.showMessageDialog(null, "Finalizando prueba unitaria #" + count);

	}
	@AfterAll
	static void metodoAA() throws Exception {
		JOptionPane.showMessageDialog(null, "Finalizando prueba unitaria bip bup");

	}
}
