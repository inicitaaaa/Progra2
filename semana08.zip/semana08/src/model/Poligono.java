package model;

public class Poligono {
	
	double cantidadLados;
	
	public Poligono (double cantidadLados) {
        this.cantidadLados = cantidadLados;
    }
	public double CalcularARea() {
	return 0;
		
	}
	public double CalcularPerimetro() {
	return 0;
	
	}
	
	
	
}
