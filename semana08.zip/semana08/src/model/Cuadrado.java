package model;

public class Cuadrado extends Poligono {
	
	    private double lado;

	    public Cuadrado(double lado) {
	        super(4);
	        this.lado = lado;
	    }
	    
	    @Override
	    public double CalcularARea() {
	        return lado * lado;
	    }
	    @Override
	    public double CalcularPerimetro() {
	        return 4 * lado;
	    }
	}
	