package model;

public class Persona {

	private String nombre;
	private int edad;
	private String dirrecion;
	private boolean activo;
	
	public Persona() {

	}

	public Persona(String nombre, int edad, String dirrecion, boolean activo) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.dirrecion = dirrecion;
		this.activo = activo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getDirrecion() {
		return dirrecion;
	}

	public void setDirrecion(String dirrecion) {
		this.dirrecion = dirrecion;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
	
	
	
}
