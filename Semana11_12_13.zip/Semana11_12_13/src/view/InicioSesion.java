package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JEditorPane;
import java.awt.Canvas;
import javax.swing.JLayeredPane;
import java.awt.Label;

public class InicioSesion extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfUsuario;
	private JTextField tfPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InicioSesion frame = new InicioSesion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InicioSesion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 310);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuario = new JLabel("usuario");
		lblUsuario.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 11));
		lblUsuario.setBounds(246, 65, 46, 14);
		contentPane.add(lblUsuario);
		
		JLabel lblPass = new JLabel("Contraseña");
		lblPass.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 11));
		lblPass.setBounds(230, 106, 78, 14);
		contentPane.add(lblPass);
		
		tfUsuario = new JTextField();
		tfUsuario.setBounds(318, 63, 86, 20);
		contentPane.add(tfUsuario);
		tfUsuario.setColumns(10);
		
		tfPass = new JTextField();
		tfPass.setBounds(318, 104, 86, 20);
		contentPane.add(tfPass);
		tfPass.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Inicio de Sesion");
		lblNewLabel.setForeground(new Color(0, 128, 192));
		lblNewLabel.setFont(new Font("Yu Gothic UI", Font.BOLD, 16));
		lblNewLabel.setBounds(259, 11, 145, 30);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(157, 200, 225));
		panel.setBackground(new Color(157, 200, 225));
		panel.setBounds(0, 0, 183, 271);
		contentPane.add(panel);
		panel.setLayout(null);
		
		Canvas canvas = new Canvas();
		canvas.setBounds(91, 5, 0, 0);
		panel.add(canvas);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\laboratorio\\eclipse-workspace\\Semana11_12_13\\src\\imagenes\\viewprofileimage.jpg");

		JLabel lblImagen = new JLabel(icon);
		lblImagen.setBounds(10, 10, 160, 200); 
		panel.add(lblImagen);
		
		
		JButton btnInicio = new JButton("Ingresar");
		btnInicio.setBounds(265, 145, 97, 23);
		contentPane.add(btnInicio);
		btnInicio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String usuario = "admin";
				String pass = "1234";
				
				if (usuario.equals(tfUsuario.getText()) && pass.equals(tfPass.getText())) {
					JOptionPane.showMessageDialog(btnInicio, "Acceso autorizado");
					
				} else {
					JOptionPane.showMessageDialog(btnInicio, "Acceso denegado", "Error", JOptionPane.ERROR_MESSAGE);
					
					
					
				}
			}
		});

	}
}
