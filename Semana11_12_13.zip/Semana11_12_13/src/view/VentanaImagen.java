package view;
import javax.swing.*;
public class VentanaImagen {

	    public static void main(String[] args) {
	       
	    }
	}


